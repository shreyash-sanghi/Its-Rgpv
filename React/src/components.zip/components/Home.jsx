import React, { useState,useEffect } from "react";
import Hero from "./Hero";
import Ourapp from "./Ourapp";
import Partners from "./Partners";
import Cards from "./Cards";
import SportsGroup from "./SportsGroup.jsx";
import Fest from "./Fest.jsx";
import Nss from './Nss'
import Dataset from "./Dataset";
import Team from "./Team";
import Footer from "./Footer";
import Inzio from "./Inzio";
import MemoriesGlimpses from "./MemoriesGlimpses.jsx";
import Placement from "./Placement.jsx";
import MainDashboard from "./MainDashboard.jsx";
import Update from "./Update.jsx";
import DepartmentalClubs from "./DepartmentalClubs";
import NotesCTA from "./NotesCTA.jsx";
import Navbar from './Navbar.jsx'
import axios from "axios";
import { useNavigate } from "react-router-dom";
import EventData from "./EventData.jsx"

const Home = () => {
  const navigate = useNavigate();

  const co =document.cookie.split('=');
  const token = co[1];
  
  const getdata =async(e)=>{
    try{
    const responce = await axios.get(`http://127.0.0.1:4000/${token}`)
    const data = responce.data;
    const Mid = data.id;
    const Email = data.Email;
    if(Email==='shreyash123jain@gmail.com'){
    axios.defaults.headers.common["Authorization"] = token;
    navigate(`/maindashboard/${Mid}`)
   }else{
    axios.defaults.headers.common["Authorization"] = token;
    navigate(`/personalpage/${Mid}`)
    }
  }catch(error){
    alert("They have some error please login again...")
    navigate("/")
  }
}

   if(token !== ''|| token==='undefined'){
    useEffect(() => {
      getdata();
    },[])
   }
  return (
    <>
    {/* <MainDashboard></MainDashboard> */}
    {/* <Update></Update> */}
    <Navbar></Navbar>
    <Hero></Hero>
      <Fest></Fest>
      <EventData/>
      <Cards></Cards>
      <Inzio></Inzio>
      <Nss></Nss>
      <DepartmentalClubs></DepartmentalClubs>
      <MemoriesGlimpses></MemoriesGlimpses>
      <SportsGroup></SportsGroup>
      <Partners></Partners>
      {/* <Dataset></Dataset> */}
      {/* <NotesCTA></NotesCTA> */}
      <Placement></Placement>
      <Ourapp></Ourapp>
      <Team></Team>
      <Footer></Footer>
    </>
  );
   
};

export default Home;