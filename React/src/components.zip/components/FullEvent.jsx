import React from "react";
import Update from "./Update";
import PastEvent from "./PastEvent"

const FullEvent = ()=>{
    return(
        <>
        
        <Update/>
        <PastEvent/>
        </>
    )
}

export default FullEvent;