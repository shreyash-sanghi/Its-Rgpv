export const eveData = [
    {
        id: 1,
        year: 2020,
        Events: 7,
        userLost: 824,
    },
    {
        id: 2,
        year: 2021,
        Events: 5,
        userLost: 824,
    },
    {
        id: 3,
        year: 2022,
        Events: 4,
        userLost: 824,
    },
    {
        id: 4,
        year: 2023,
        Events: 2,
        userLost: 824,
    }
]